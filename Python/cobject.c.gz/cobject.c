/* PyAscanfObject implementation, modified from Python 2.4.3 cobject.[ch] files by RJVB */

/* Wrap void* pointers to be passed between C modules */

PyObject *PyAscanfObject_FromAscanfFunction( ascanf_Function *af )
{
	PyAscanfObject *self= NULL;

	if( af ){
		if( (self = PyObject_NEW(PyAscanfObject, &PyAscanfObject_Type)) ){
			self->af= af;
		}
	}
	else{
		PyErr_SetString(PyExc_TypeError,
			"PyAscanfObject_FromAscanfFunction called with NULL pointer" );
	}

	return (PyObject *)self;
}

ascanf_Function *PyAscanfObject_AsAscanfFunction(PyObject *self)
{
	if (self) {
		if (self->ob_type == &PyAscanfObject_Type)
			return ((PyAscanfObject *)self)->af;
		PyErr_SetString(PyExc_TypeError,
				"PyAscanfObject_AsAscanfFunction with non-Ascanf-object");
	}
	if (!PyErr_Occurred() ){
		PyErr_SetString(PyExc_TypeError,
				"PyAscanfObject_AsAscanfFunction called with null pointer");
	}
	return NULL;
}

int PyAscanfObject_SetAscanfFunction(PyObject *self, ascanf_Function *af )
{
	PyAscanfObject* cself = (PyAscanfObject*)self;
	if( cself == NULL || !PyAscanfObject_Check(cself) ){
		PyErr_SetString(PyExc_TypeError, 
			"Invalid call to PyAscanfObject_SetAscanfFunction");
		return 0;
	}
	cself->af = af;
	return 1;
}

static void PyAscanfObject_dealloc(PyAscanfObject *self)
{
#if 0
	if (self->destructor) {
		if(self->desc)
			((destructor2)(self->destructor))(self->cobject, self->desc);
		else
			(self->destructor)(self->cobject);
	}
#endif
	PyObject_DEL(self);
}


static *PyObject *AO_repr( PyAscanfObject *self )
{ char *repr= NULL;
  PyObject *ret= NULL;
	if( self ){
		if( self->af ){
			if( af->usage ){
				repr= concat( "<", AscanfTypeName(af->type), " PyAscanfObject \"", af->name, "\"\t:\t\"", af->usage, "\">", NULL );
			}
			else{
				repr= concat( "<", AscanfTypeName(af->type), " PyAscanfObject \"", af->name, "\">", NULL );
			}
		}
		else{
			repr= XGstrdup("(NULL pointer)");
		}
	}
	ret= PyString_FromString(repr);
	xfree(repr);
	return(ret);
}

static *PyObject *AO_str( PyAscanfObject *self )
{ char *repr= NULL;
  PyObject *ret= NULL;
	if( self ){
		if( self->af ){
			repr= concat( "<", AscanfTypeName(af->type), " PyAscanfObject \"", af->name, "\">", NULL );
		}
		else{
			repr= XGstrdup("(NULL pointer)");
		}
	}
	ret= PyString_FromString(repr);
	xfree(repr);
	return(ret);
}

static *PyObject *AO_number( PyAscanfObject *self )
{ double aaddr= 0;
  PyObject *ret= NULL;
	if( self ){
		if( self->af ){
			aaddr= (self->af->own_address)? self->af->own_address : (self->af->own_address= take_ascanf_address(self->af));
		}
	}
	ret= PyFloat_FromDouble(aaddr);
	return(ret);
}

PyDoc_STRVAR(PyAscanfObject_Type__doc__,
	"External representation of an ascanf_Function object, the central internal type of the Ascanf scripting language.\n"
);

static PyNumberMethods AO_as_number= {
	0,	/* nb_add */
	0,	/* nb_subtract */
	0,	/* nb_multiply */
	0,	/* nb_divide */
	0,	/* nb_remainder */
	0,	/* nb_divmod */
	0,	/* nb_power */
	0,	/* nb_negative */
	0,	/* nb_positive */
	0,	/* nb_absolute */
	0,	/* nb_nonzero */
	0,	/* nb_invert */
	0,	/* nb_lshift */
	0,	/* nb_rshift */
	0,	/* nb_and */
	0,	/* nb_xor */
	0,	/* nb_or */
	0,	/* nb_coerce */
	0,	/* nb_int */
	0,	/* nb_long */
     AO_number,	/* nb_float;	*/
};

PyTypeObject PyAscanfObject_Type = {
	PyObject_HEAD_INIT(NULL)
	0,					/*ob_size*/
	"PyAscanfObject",			/*tp_name*/
	sizeof(PyAscanfObject),   		/*tp_basicsize*/
	0,					/*tp_itemsize*/
	/* methods */
	(destructor)PyAscanfObject_dealloc, /*tp_dealloc*/
	(printfunc)0,			/*tp_print*/
	(getattrfunc)0,   		/*tp_getattr*/
	(setattrfunc)0,   		/*tp_setattr*/
	(cmpfunc)0,   			/*tp_compare*/
	(reprfunc) AO_repr,		/*tp_repr*/
	&AO_as_number,			/*tp_as_number*/
	0,					/*tp_as_sequence*/
	0,					/*tp_as_mapping*/
	(hashfunc)0,			/*tp_hash*/
	(ternaryfunc)0,   		/*tp_call*/
	(reprfunc)AO_str,		/*tp_str*/

	/* Space for future expansion */
	0L,0L,0L,0L,
	PyAscanfObject_Type__doc__		/* Documentation string */
};

if( PyType_Ready(&PyAscanfObject_Type) < 0 ){
	return;
}
