/* (C) Copyright 1999 Patrick Lambert <drow@wildstar.net>
 *
 * This program is free software. You can use, copy and modify it under
 * the terms of the GPL. See the file COPYING for the full GPL license.
*/ 

#include <gtk/gtk.h>
#include <stdio.h>
#include <strings.h>
#include <stdlib.h>

int i;
FILE *fd;
char temp[512];
GtkWidget *window, *vbox, *label, *button, *entry_box, *hbox, *text, *table, *vscrollbar, *cb;
GList *cbitems;
FILE *output;        /* --output -o */
char title[512];     /* --title, -t */
char exit_code[512]; /* --exit-code */
char filename[512];  /* --edit-file, -ef */
int pos;             /* --position, -p */
int size;            /* --size, -s */
int append;          /* --append-eol, -eol */
int combo;           /* --choice, -c */
